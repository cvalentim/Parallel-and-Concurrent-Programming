mpirun -np $1 a.out <$2 >$3
